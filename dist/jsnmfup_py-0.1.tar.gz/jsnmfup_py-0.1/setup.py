from distutils.core import setup
setup(
      name='JSNMFuP.py',
      version='0.1',
      author='Bai Zhang',
      py_modules=['code.model']
)